# Java Weekly Practice Problems

This repository contains Java practice programs organized by week and category.

## Folders
- Week1-Practice
- Week2-Practice
- Category-C-Arrays
- Arrays-Methods-Practice

Each program is stored as a separate `.java` file.
